#ILUSION OPTICA COMBINANDO CUADROS NEGROS Y LINEAS ROJAS
import turtle

#Definimos los parámetros de la línea:
#Punto inicial (xFrom,yFrom) a punto final (xTo,yTo):
def drawLine(xFrom, yFrom, xTo, yTo, color):
    global myLapiz
    
    #Alzar lápiz
    myLapiz.penup()
    myLapiz.color(color)
    myLapiz.goto(xFrom,yFrom)
    
    #Bajar lápiz
    myLapiz.pendown()
    myLapiz.goto(xTo,yTo)

#Definimos los parámetros del cuadrado:
def drawSquare(x, y, size, color):
    global myLapiz
    myLapiz.setheading(0)
    
    #Alzar lápiz
    myLapiz.penup()
    myLapiz.goto(x,y)
    myLapiz.color(color)
    myLapiz.fillcolor(color)    
    
    #Bajar lápiz
    myLapiz.pendown()
    
    #Rellenar la figura del color:
    myLapiz.begin_fill()
    myLapiz.forward(size)
    myLapiz.left(90)
    myLapiz.forward(size)
    myLapiz.left(90)
    myLapiz.forward(size)
    myLapiz.left(90)
    myLapiz.forward(size)
    myLapiz.end_fill()
    
myLapiz = turtle.Turtle()

#Establecer la figura del lápiz, flecha o tortuga (turtle)
myLapiz.shape("turtle")

#Velocidad del trazado de la línea:
myLapiz.speed(60)

#Crear un conjunto de cuadros negros y lineas rojas
#de acuerdo a las siguientes coordenadas:


drawSquare(-400,-400,800,'gray')


for i in range(4):
    for j in range(4):
        drawSquare(80*i+20,80*j,60,"Black")


for i in range(6):
    for j in range(4):
        drawSquare(-80*i+20,80*j,60,"Black")


for i in range(6):
    for j in range(5):
        drawSquare(80*i+20,-80*j,60,"Black")


for i in range(6):
    for j in range(5):
        drawSquare(-80*i+20,-80*j,60,"Black")



#Definimos los parámetros del círculo 
def drawCircle(x, y, radius, color):
    global myLapiz
    myLapiz.setheading(0)
    
    #Alzar Lápiz
    myLapiz.penup()
    
    myLapiz.color(color)
    myLapiz.fillcolor(color)
    
    #Moverse al siguiente punto
    myLapiz.goto(x,y-radius)
    
    #Realizar figura
    myLapiz.begin_fill()
    myLapiz.circle(radius)
    myLapiz.end_fill()
    
    #Bajar Lápiz
    myLapiz.pendown()


for i in range(6):
    for j in range(4):
        drawCircle(80*i+10,80*j-10,18,"white")


for i in range(6):
    for j in range(4):
        drawCircle(-80*i+10,80*j-10,18,"white")


for i in range(6):
    for j in range(5):
        drawCircle(80*i+10,-80*j-10,18,"white")


for i in range(6):
    for j in range(5):
        drawCircle(-80*i+10,-80*j-10,18,"white")
turtle.done()