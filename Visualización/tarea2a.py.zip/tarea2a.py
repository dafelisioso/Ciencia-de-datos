import turtle


#Definimos los parámetros de las líneas:
def drawLine(xFrom, yFrom, xTo, yTo, color):
    global myLapiz
    
    #Alzar el lápiz
    myLapiz.penup()
    myLapiz.color(color)
    
    #Establecer el punto (x,y) de origen:
    myLapiz.goto(xFrom,yFrom)
    
    #Bajar el lápiz
    myLapiz.pendown()
    
    #Moverse al segundo punto
    myLapiz.goto(xTo,yTo)

myLapiz = turtle.Turtle()

#Forma del lapiz: flecha o tortuga (turtle)
myLapiz.shape("arrow")

#Velocidad del trazo de línea
myLapiz.speed(80)

#Crear varias líneas a partir de un solo punto de origen:
for i in range(40):
    
    drawLine(0,0,30*i,300 + 150,"Black")
    drawLine(0,0,-30*i,300 + 150,"Black")

for i in range(40):
    drawLine(0,0,-30*i,-300 - 150,"Black")
    drawLine(0,0,30*i,-300 - 150,"Black")



drawLine(-400,100,400,100,"purple")
drawLine(-400,-100,400,-100,"purple")

turtle.done()

